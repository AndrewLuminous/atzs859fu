#!/usr/bin/env python3
"""Проверка алкотестера ATZS-859FU по протоколу поставщика (этап 2 плана).

Нужен только Python 3 из Raspberry Pi OS, ставить ничего не надо.

    python3 alcotest.py            сенсорный интерфейс на http://localhost:8080
    python3 alcotest.py --quick    то же, сразу в быстром режиме: алкотестер сам ждёт выдоха
    python3 alcotest.py --cli      консоль: отправить "старт" и печатать ответы
    python3 alcotest.py --find     показать порты и на каком из них алкотестер
    python3 alcotest.py --demo     то же без устройства, со встроенным эмулятором

Каждый запуск пишет все пакеты в CSV в папку alcotest-logs рядом со скриптом.
"""

import argparse
import collections
import csv
import datetime
import errno
import fcntl
import json
import os
import queue
import select
import signal
import struct
import sys
import termios
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))

# По умолчанию ищем порт сами: перебираем CH340 и шлём каждому стоп.
# Порт можно указать и руками, например по разъёму, как на старом терминале:
# /dev/serial/by-path/platform-xhci-hcd.1-usb-0:1.4.2:1.0-port0
DEFAULT_PORT = "auto"
# Алкотестер сидит на CH340. Другие порты (тонометр, FT232, CP210x, STM32) при поиске не открываем
CANDIDATE_IDS = {"1a86:7523"}
PROBE_TIMEOUT = 0.4   # ATZS-859FU отвечает на стоп примерно за 15 мс
PROBE_TRIES = 3       # только что воткнутый алкотестер может ответить не с первого раза
RECHECK_AFTER = 10    # через сколько секунд снова проверять порт, который не ответил как алкотестер
FRESH_PORT = 10       # порт моложе стольких секунд не запоминаем как "не алкотестер": он мог ещё грузиться

BAUDS = {9600: termios.B9600, 19200: termios.B19200, 38400: termios.B38400,
         57600: termios.B57600, 115200: termios.B115200}
UNITS = {0: "%BAC", 1: "мг/л", 2: "мг/100 мл", 3: "г/л"}
ACTIVE = ("starting", "countdown", "blow", "collecting", "analyzing")

# Сколько секунд устройство может молчать на шаге, потом считаем что зависло.
# На реальном устройстве: отсчёт 1 с, сбор данных 2 с, анализ 4 с.
SILENCE_LIMITS = {"countdown": 3, "collecting": 6, "analyzing": 10}
STEP_NAMES = {"countdown": "Обратный отсчёт", "collecting": "Сбор данных", "analyzing": "Анализ данных"}
# Больше 5000 (5 мг/л при делителе 1000) быть не может, значит сбой датчика или битый пакет
MAX_RAW = 5000
# После ошибки выдоха устройство через 2 с снова ждёт выдоха само. Если дуют без остановки,
# ошибки идут одна за другой. После ERRORS_BEFORE_PAUSE подряд останавливаем тест на PAUSE секунд
ERRORS_BEFORE_PAUSE = 3
PAUSE = 10
STATS = ("tests", "results", "blow_errors", "faults", "no_response", "junk", "lost")

# Значения для Linux на случай, если их нет в модуле termios
TIOCEXCL = getattr(termios, "TIOCEXCL", 0x540C)
TIOCNXCL = getattr(termios, "TIOCNXCL", 0x540D)
TIOCMBIS = getattr(termios, "TIOCMBIS", 0x5416)
TIOCMBIC = getattr(termios, "TIOCMBIC", 0x5417)
TIOCMGET = getattr(termios, "TIOCMGET", 0x5415)
TIOCM_DTR = getattr(termios, "TIOCM_DTR", 0x002)
TIOCM_RTS = getattr(termios, "TIOCM_RTS", 0x004)
MODEM_LINES = (("DTR", TIOCM_DTR), ("RTS", TIOCM_RTS), ("CTS", getattr(termios, "TIOCM_CTS", 0x020)),
               ("DSR", getattr(termios, "TIOCM_DSR", 0x100)), ("CD", getattr(termios, "TIOCM_CAR", 0x040)),
               ("RI", getattr(termios, "TIOCM_RNG", 0x080)))


# ---------- протокол ----------

def crc16_modbus(data):
    crc = 0xFFFF
    for b in data:
        crc ^= b
        for _ in range(8):
            crc = (crc >> 1) ^ 0xA001 if crc & 1 else crc >> 1
    return crc


def make_frame(kind, data=b""):
    """FD | длина всего пакета | тип | данные | CRC, старший байт CRC первым."""
    body = bytes([0xFD, len(data) + 5, kind]) + bytes(data)
    crc = crc16_modbus(body)
    return body + bytes([crc >> 8, crc & 0xFF])


CMD_START = make_frame(0x02)
CMD_STOP = make_frame(0x08)
# Сверка с примерами из документа поставщика
assert CMD_START == bytes.fromhex("FD0502A162")
assert CMD_STOP == bytes.fromhex("FD0508A6E2")


def cmd_unit(unit):
    return make_frame(0x17, [unit])


def hexs(data):
    return " ".join(f"{b:02X}" for b in data)


def describe(fr):
    """Пакет от устройства -> (текст для журнала, (состояние, значение) или None)."""
    kind, data = fr[2], fr[3:-2]
    if kind == 0x02:
        if data:
            return f"Обратный отсчёт: {data[0]}", ("countdown", data[0])
        return "Запуск теста (эхо)", None
    if kind == 0x03:
        return "Ожидание выдоха: дуйте", ("blow", None)
    if kind == 0x04:
        return "Сбор данных", ("collecting", None)
    if kind == 0x05:
        return "Ошибка выдоха: выдох прерван", ("error", None)
    if kind == 0x06:
        return "Анализ данных", ("analyzing", None)
    if kind == 0x07:
        raw = int.from_bytes(data, "big")
        return f"Результат: сырое значение {raw}", ("result", raw)
    if kind == 0x08:
        return "Завершение теста (подтверждение)", ("stop_ack", None)
    if kind == 0x17:
        if data:
            return f"Единицы: {UNITS.get(data[0], data[0])}", ("unit_ack", None)
        return "Единицы подтверждены", ("unit_ack", None)
    return f"Неизвестный тип 0x{kind:02X}", None


class FrameParser:
    """Собирает пакеты из потока байт: данные из порта приходят кусками.

    feed() возвращает список ("frame", пакет, порядок_crc) и ("junk", байты, None).
    Порядок CRC: "doc" - как в документе, "swapped" - младший байт первым.
    """

    def __init__(self):
        self.buf = bytearray()
        self.junk = bytearray()
        self.last = 0.0

    def feed(self, chunk, now):
        if chunk:
            self.buf += chunk
            self.last = now
        out = []
        while True:
            self._parse(out)
            if self.buf and now - self.last > 0.5:
                # обрывок пакета так и не дописался: сдвигаемся на байт
                self.junk.append(self.buf.pop(0))
                continue
            break
        if self.junk and not self.buf and now - self.last > 0.2:
            out.append(("junk", bytes(self.junk), None))
            self.junk.clear()
        return out

    def _parse(self, out):
        while self.buf:
            if self.buf[0] != 0xFD:
                self.junk.append(self.buf.pop(0))
                continue
            if len(self.buf) < 2:
                return
            length = self.buf[1]
            if not 5 <= length <= 64:
                self.junk.append(self.buf.pop(0))
                continue
            if len(self.buf) < length:
                return
            fr = bytes(self.buf[:length])
            crc = crc16_modbus(fr[:-2])
            if fr[-2:] == bytes([crc >> 8, crc & 0xFF]):
                order = "doc"
            elif fr[-2:] == bytes([crc & 0xFF, crc >> 8]):
                order = "swapped"
            else:
                self.junk.append(self.buf.pop(0))
                continue
            if self.junk:
                out.append(("junk", bytes(self.junk), None))
                self.junk.clear()
            out.append(("frame", fr, order))
            del self.buf[:length]


# ---------- порт и состояние теста ----------

def port_users(path):
    """Другие процессы, у которых открыт этот порт: [(pid, имя)].

    Процессы других пользователей (например, root) так не видны: их /proc/PID/fd закрыт.
    """
    target = os.path.realpath(path)
    users = []
    for pid in os.listdir("/proc"):
        if not pid.isdigit() or int(pid) == os.getpid():
            continue
        try:
            fds = os.listdir(f"/proc/{pid}/fd")
        except OSError:
            continue
        for fd in fds:
            try:
                if os.readlink(f"/proc/{pid}/fd/{fd}") == target:
                    with open(f"/proc/{pid}/comm") as f:
                        users.append((int(pid), f.read().strip()))
                    break
            except OSError:
                continue
    return users


def usb_device(tty):
    """Папка USB-устройства в /sys, к которому относится tty, или None."""
    d = os.path.realpath(f"/sys/class/tty/{tty}/device")
    # от порта поднимаемся к самому USB-устройству: у него есть idVendor
    while d != "/" and not os.path.exists(os.path.join(d, "idVendor")):
        d = os.path.dirname(d)
    return None if d == "/" else d


def sysfs_read(d, name):
    try:
        with open(os.path.join(d, name)) as f:
            return f.read().strip()
    except OSError:
        return "нет"


def usb_info(path):
    """Какой USB-переходник стоит за портом и куда он воткнут (из /sys) - для журнала."""
    try:
        tty = os.path.basename(os.path.realpath(path))
        d = usb_device(tty)
        if d is None:
            return f"{tty}: не USB-устройство"
        driver = os.path.basename(os.path.realpath(f"/sys/class/tty/{tty}/device/driver"))
        return (f"{tty}: USB {sysfs_read(d, 'idVendor')}:{sysfs_read(d, 'idProduct')} "
                f"«{sysfs_read(d, 'product')}», разъём {os.path.basename(d)}, {sysfs_read(d, 'speed')} Мбит/с, "
                f"драйвер {driver}, серийный номер {sysfs_read(d, 'serial')}")
    except OSError as e:
        return f"сведения об USB недоступны: {e}"


def serial_ports():
    """Последовательные USB-порты, которые сейчас видит система: [(путь, "VID:PID", название)]."""
    ports = []
    try:
        ttys = sorted(os.listdir("/sys/class/tty"))
    except OSError:
        return ports
    for tty in ttys:
        if not tty.startswith(("ttyUSB", "ttyACM")):
            continue
        d = usb_device(tty)
        if d:
            ports.append((f"/dev/{tty}", f"{sysfs_read(d, 'idVendor')}:{sysfs_read(d, 'idProduct')}",
                          sysfs_read(d, "product")))
    return ports


def describe_ports(ports):
    if not ports:
        return "ни одного последовательного USB-порта (ttyUSB, ttyACM)"
    return "; ".join(f"{path} — {ids} «{name}»" for path, ids, name in ports)


def modem_lines(fd):
    try:
        bits = struct.unpack("I", fcntl.ioctl(fd, TIOCMGET, struct.pack("I", 0)))[0]
    except OSError:
        return "недоступны"
    return " ".join(f"{name}={int(bool(bits & bit))}" for name, bit in MODEM_LINES)


def open_port(path, baud):
    """Открыть и настроить порт монопольно: пока он открыт, другие программы его не откроют."""
    fd = os.open(path, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
    try:
        fcntl.ioctl(fd, TIOCEXCL)
        configure(fd, baud)
    except OSError:
        close_port(fd)
        raise
    return fd


def close_port(fd):
    try:
        fcntl.ioctl(fd, TIOCNXCL)  # снять монопольный доступ, иначе порт не откроется снова
    except OSError:
        pass
    try:
        os.close(fd)
    except OSError:
        pass


def probe(fd):
    """Отправить "стоп": ATZS-859FU отвечает тем же пакетом. Безопасно - "стоп" только завершает тест.

    Возвращает (это алкотестер, что пришло в ответ).
    """
    parser, got = FrameParser(), b""
    for _ in range(PROBE_TRIES):
        os.write(fd, CMD_STOP)
        end = time.time() + PROBE_TIMEOUT
        while time.time() < end:
            ready, _, _ = select.select([fd], [], [], 0.05)
            chunk = os.read(fd, 256) if ready else b""
            got += chunk
            for kind, data, _ in parser.feed(chunk, time.time()):
                if kind == "frame" and data == CMD_STOP:
                    return True, got
    return False, got


def port_age(path):
    """Сколько секунд назад появился порт (по времени создания файла устройства)."""
    try:
        return time.time() - os.stat(path).st_ctime
    except OSError:
        return 0.0


def usb_key(path):
    """Чем этот экземпляр устройства отличается от другого: разъём и номер на шине (меняется при переподключении)."""
    d = usb_device(os.path.basename(os.path.realpath(path)))
    return d and (os.path.basename(d), sysfs_read(d, "devnum"))


def scan_ports(baud, log=None, cache=None, first=True):
    """Найти алкотестер среди переходников CH340.

    Возвращает (путь, fd, заметки, занятые): fd открыт только у найденного порта.
    Заметки - по строке на каждый порт, занятые - кто держит переходники CH340.
    cache - {путь: (usb_key, время, заметка)} для портов, которые уже не ответили как алкотестер.
    first=False - проверить все порты (для --find), найденные закрываются.
    """
    found, notes, busy = None, [], []
    for path, ids, name in serial_ports():
        title = f"{path} — {ids} «{name}»"
        if ids not in CANDIDATE_IDS:
            notes.append(f"{title}: не CH340, не трогаю")
            continue
        users = port_users(path)
        if users:
            holder = ", ".join(f"{n} (PID {p})" for p, n in users)
            notes.append(f"{title}: занят — {holder}")
            busy.append(holder)
            continue
        old = cache.get(path) if cache is not None else None
        if old and old[0] == usb_key(path) and time.time() - old[1] < RECHECK_AFTER:
            notes.append(old[2])
            continue
        try:
            fd = open_port(path, baud)
        except OSError as e:
            if e.errno == errno.EBUSY:
                busy.append("программа, которую отсюда не видно")
            notes.append(f"{title}: не открывается ({e.strerror})")
            continue
        try:
            if log:
                log("tx", CMD_STOP, f"Поиск алкотестера: проверяю {path} командой «стоп»")
            ok, got = probe(fd)
        except OSError as e:
            ok, got = False, b""
        if log:
            log("rx" if got else "info", got, f"Поиск: {path} " + ("ответил как ATZS-859FU" if ok
                                                                   else "не ответил как ATZS-859FU"))
        if ok:
            notes.append(f"{title}: ATZS-859FU")
            if first:
                return path, fd, notes, busy
            found = found or path
            close_port(fd)
            continue
        close_port(fd)
        if port_age(path) < FRESH_PORT:
            notes.append(f"{title}: только что подключён и пока не ответил, проверю ещё раз")
            continue
        note = f"{title}: на «стоп» не ответил как ATZS-859FU (проверю снова через {RECHECK_AFTER} с)"
        notes.append(note)
        if cache is not None:
            cache[path] = (usb_key(path), time.time(), note)
    return found, None, notes, busy


def configure(fd, baud):
    attrs = termios.tcgetattr(fd)
    attrs[0] = 0                                           # iflag: без преобразований
    attrs[1] = 0                                           # oflag
    attrs[2] = termios.CS8 | termios.CREAD | termios.CLOCAL  # 8N1, без управления потоком
    attrs[3] = 0                                           # lflag: сырой режим
    attrs[4] = attrs[5] = BAUDS[baud]
    attrs[6][termios.VMIN] = 0
    attrs[6][termios.VTIME] = 0
    termios.tcsetattr(fd, termios.TCSANOW, attrs)
    termios.tcflush(fd, termios.TCIOFLUSH)
    try:
        # как в SSCOM у поставщика: DTR включён, RTS выключен
        fcntl.ioctl(fd, TIOCMBIS, struct.pack("I", TIOCM_DTR))
        fcntl.ioctl(fd, TIOCMBIC, struct.pack("I", TIOCM_RTS))
    except OSError:
        pass  # у псевдотерминала в демо-режиме этих линий нет


class Alcotester:
    """Порт, разбор пакетов и состояние теста. Все события уходят в emit(dict).

    Быстрый режим (quick): тест запускается заранее и после каждого результата,
    так что алкотестер всё время ждёт выдоха и кнопку нажимать не нужно.
    """

    def __init__(self, path, baud, emit, journal, demo=False, unit=None, quick=False, rearm=60):
        self.path, self.baud, self.emit, self.journal, self.demo = path, baud, emit, journal, demo
        self.port = path      # реальный порт, при auto его находит поиск
        self.checked = {}     # порты, которые не ответили как алкотестер (кэш поиска)
        self.fd = None
        self.lock = threading.RLock()
        self.parser = FrameParser()
        self.state, self.value, self.since = "no_device", None, time.time()
        self.init_unit = unit  # какие единицы выставить при подключении; None - не трогать
        self.pending_unit = None
        self.unit = None
        self.quick, self.rearm = quick, rearm
        self.last = None        # последний результат: (сырое значение, единицы, время)
        self.deadline = None    # до какого времени ждать ответа на "старт"
        self.start_at = None    # (когда, текст): отложенный старт после стопа
        self.stop_sent = 0.0    # когда отправили стоп, чтобы отличить эхо от стопа самого устройства
        self.stats = dict.fromkeys(STATS, 0)  # сбои и тесты за этот запуск
        self.errors_in_row = 0  # прерванных выдохов подряд
        self.junk_times = collections.deque(maxlen=5)
        self.junk_warned = 0.0
        self.missing_logged = False
        self.t0 = self.stats_logged = time.time()
        u = os.uname()
        self._log("info", b"", f"Запуск: {' '.join(sys.argv)} | Python {sys.version.split()[0]} | "
                               f"{u.sysname} {u.release} {u.machine} | пользователь "
                               f"{os.getenv('USER') or os.getuid()} | PID {os.getpid()}")
        threading.Thread(target=self._loop, daemon=True).start()

    @property
    def connected(self):
        return self.fd is not None

    def snapshot(self):
        with self.lock:
            last = None
            if self.last:
                last = {"value": self.last[0], "unit": self.last[1], "age": time.time() - self.last[2]}
            return {"type": "snapshot", "state": self.state, "value": self.value,
                    "age": time.time() - self.since, "unit": self.unit, "baud": self.baud,
                    "path": self.port, "connected": self.connected, "demo": self.demo,
                    "quick": self.quick, "last": last, "stats": self.stats}

    # ----- команды

    def start_test(self):
        with self.lock:
            self._require_port()
            self.errors_in_row = 0
            self._begin("Запуск теста")

    def stop_test(self):
        with self.lock:
            self._require_port()
            if self.quick:
                self._set_quick(False)
            self.deadline = self.start_at = None
            self._send_stop("Завершение теста")
            if self.state in ACTIVE + ("error", "fault", "no_response", "cooldown"):
                self._set_state("stopped")

    def set_quick(self, on):
        with self.lock:
            self._set_quick(on)
            if not on and self.fd is not None and self.state in ACTIVE:
                self.deadline = self.start_at = None
                self._send_stop("Завершение теста: быстрый режим выключен")
                self._set_state("stopped")

    def set_unit(self, unit):
        if unit not in UNITS:
            raise ValueError("Таких единиц нет в протоколе")
        with self.lock:
            self._require_port()
            if self.quick:
                raise RuntimeError("В быстром режиме единицы не меняются: переключитесь на «По кнопке»")
            if self.state in ACTIVE:
                raise RuntimeError("Единицы можно менять только между тестами")
            self.init_unit = unit  # после переподключения ставим те же, что выбрали на экране
            self._send_unit(unit)

    # ----- внутреннее

    def _require_port(self):
        if self.fd is None:
            raise RuntimeError("Алкотестер не подключён")

    def _send(self, data, text):
        os.write(self.fd, data)
        self._log("tx", data, text)

    def _send_stop(self, text):
        self.stop_sent = time.time()
        self._send(CMD_STOP, text)

    def _send_start(self, text):
        self.start_at = None
        self._send(CMD_START, text)
        self.deadline = time.time() + 3
        self._count("tests")

    def _count(self, key):
        self.stats[key] += 1
        self.emit({"type": "stats", "stats": self.stats})

    def _fault(self, text):
        """Сбой посреди теста: выводим устройство из теста и сообщаем, что случилось."""
        self._count("faults")
        self._log("error", b"", text)
        self.deadline = self.start_at = None
        self._send_stop("Завершение теста после сбоя")
        self._set_state("fault", text)

    def _send_unit(self, unit):
        self.unit = unit
        self._send(cmd_unit(unit), f"Установить единицы: {UNITS[unit]}")
        self.emit({"type": "unit", "unit": unit})

    def _begin(self, text):
        self.start_at = None
        if self.state in ("error", "fault", "no_response", "countdown", "blow", "collecting", "analyzing"):
            # устройство могло остаться в тесте, сначала останавливаем
            self._send_stop("Завершение теста перед повтором")
            self.start_at = (time.time() + 0.3, text)
        else:
            self._send_start(text)
        self._set_state("starting")

    def _set_quick(self, on):
        self.quick = on
        self._log("info", b"", "Быстрый режим включён: алкотестер сам ждёт выдоха" if on
                  else "Быстрый режим выключен")
        self.emit({"type": "mode", "quick": on})

    def _keep_ready(self, now):
        """Быстрый режим: вернуть алкотестер в ожидание выдоха, если он из него вышел."""
        age = now - self.since
        if self.state == "blow" and age > self.rearm:
            # сколько устройство само ждёт выдоха, в документе не сказано
            self._log("info", b"", f"Быстрый режим: {self.rearm:g} с без выдоха, перезапускаю тест")
        elif not (self.state in ("idle", "stopped") and age > 0.5
                  or self.state == "result" and age > 1
                  or self.state == "error" and age > 5
                  or self.state in ("no_response", "fault") and age > 10
                  or self.state == "cooldown" and age > PAUSE):
            return
        self._begin("Запуск теста (быстрый режим)")

    def note(self, direction, text):
        """Запись в журнал извне, например о нажатиях на экране."""
        with self.lock:
            self._log(direction, b"", text)

    def log_stats(self, title):
        with self.lock:
            self._log_stats(title)

    def _log_stats(self, title):
        self.stats_logged = time.time()
        names = {"tests": "запусков теста", "results": "результатов", "blow_errors": "прерванных выдохов",
                 "faults": "сбоев", "no_response": "без ответа", "junk": "испорченных пакетов",
                 "lost": "обрывов связи"}
        self._log("info", b"", title + ": " + ", ".join(f"{names[k]} {v}" for k, v in self.stats.items()))

    def _set_state(self, state, value=None):
        now = time.time()
        if state != self.state or value != self.value:
            shown = state if value is None else f"{state} = {value}"
            self._log("state", b"", f"{self.state} → {shown} (прошлый шаг длился {now - self.since:.2f} с)",
                      ui=False)
        self.state, self.value, self.since = state, value, now
        self.emit({"type": "state", "state": state, "value": value})

    def _log(self, direction, data, text, ui=True):
        """Всё идёт в CSV; на экран - кроме сырых кусков из порта и смены состояний."""
        now = time.time()
        entry = {"type": "log",
                 "t": datetime.datetime.fromtimestamp(now).strftime("%H:%M:%S.%f")[:-3],
                 "dt": round(now - self.t0, 3), "dir": direction, "state": self.state,
                 "hex": hexs(data), "text": text}
        self.journal(entry)
        if ui:
            self.emit(entry)

    def _not_found(self, text):
        if self.missing_logged != text:
            self._log("error", b"", f"{text}. Пробую раз в секунду")
            self.missing_logged = text
        if self.state != "no_device" or self.value != text:
            self._set_state("no_device", text)

    def _set_busy(self, busy):
        if self.state != "busy" or self.value != busy:
            self._log("error", b"", f"Порт занят: {busy}. Жду, пока программа его освободит")
            self._set_state("busy", busy)

    def _scan(self):
        """Поиск по всем CH340: возвращает fd найденного алкотестера или None."""
        path, fd, notes, busy = scan_ports(self.baud, log=lambda d, data, text: self._log(d, data, text),
                                           cache=self.checked)
        if path:
            self.port = path
            return fd
        if busy:
            # скорее всего, алкотестер держит программа терминала
            self._set_busy("; ".join(busy))
        else:
            self._not_found("Алкотестер не найден. " + ("; ".join(notes) if notes else
                            "Система не видит ни одного последовательного USB-порта (ttyUSB, ttyACM)"))
        return None

    def _try_open(self):
        with self.lock:
            if self.path == "auto":
                fd = self._scan()
                if fd is None:
                    return False
                return self._opened(fd, " (нашёл поиском: ответил на «стоп» как ATZS-859FU)")
            users = [] if self.demo else port_users(self.port)
            if users:
                # если две программы читают один порт, байты теряются, поэтому ждём
                self._set_busy(", ".join(f"{name} (PID {pid})" for pid, name in users))
                return False
            try:
                fd = open_port(self.port, self.baud)
            except OSError as e:
                if e.errno == errno.EBUSY:
                    self._set_busy("программа, которую отсюда не видно (запущена от другого пользователя или root)")
                    return False
                reason = {errno.ENOENT: "Такого порта нет",
                          errno.EACCES: "Нет прав на порт: пользователь должен быть в группе dialout",
                          }.get(e.errno, f"Порт не открывается: {e.strerror}")
                self._not_found(f"{reason}. Система видит: {describe_ports(serial_ports())}")
                return False
            return self._opened(fd, "")

    def _opened(self, fd, how):
        self.fd = fd
        self.missing_logged = False
        self.parser = FrameParser()
        self._log("info", b"", f"Порт открыт: {self.port}{how}, {self.baud} 8N1 | {usb_info(self.port)} | "
                               f"линии: {modem_lines(fd)}")
        self.emit({"type": "conn", "connected": True, "baud": self.baud})
        self._set_state("idle")
        # с какими единицами устройство включается, мы не знаем, поэтому ставим сами
        self.pending_unit = self.init_unit
        return True

    def _close(self):
        if self.fd is not None:
            close_port(self.fd)
            self.fd = None
            if self.path == "auto":
                self.port = "auto"  # после обрыва ищем заново, могли воткнуть в другой разъём

    def _loop(self):
        while True:
            try:
                self._step()
            except Exception:
                # чтобы одна ошибка не остановила поток чтения
                with self.lock:
                    self._log("error", b"", "Ошибка в программе: "
                              + traceback.format_exc().strip().replace("\n", " | "))
                time.sleep(1)

    def _step(self):
        if self.fd is None and not self._try_open():
            time.sleep(1)
            return
        try:
            if self.pending_unit is not None:
                with self.lock:
                    self._send_unit(self.pending_unit)
                    self.pending_unit = None
            ready, _, _ = select.select([self.fd], [], [], 0.1)
            chunk = os.read(self.fd, 512) if ready else b""
            if ready and not chunk:
                raise OSError("порт закрылся")
            if chunk:
                self._log("raw", chunk, f"Прочитано из порта: {len(chunk)} байт", ui=False)
            now = time.time()
            for kind, data, order in self.parser.feed(chunk, now):
                self._handle(kind, data, order)
            self._timers(now)
        except OSError as e:
            with self.lock:
                during = " посреди теста" if self.state in ACTIVE else ""
                self._close()
                self.deadline = self.start_at = None
                self._count("lost")
                self._log("error", b"", f"Связь с алкотестером потеряна{during}: {e}")
                self._set_state("no_device")
                self.emit({"type": "conn", "connected": False, "baud": self.baud})

    def _timers(self, now):
        with self.lock:
            if self.start_at and now >= self.start_at[0]:
                self._send_start(self.start_at[1])
            if self.deadline and now > self.deadline:
                self.deadline = None
                self._count("no_response")
                self._log("error", b"", "Нет ответа по протоколу 3 с после «старта». "
                                        "Проверьте, включён ли алкотестер")
                self._set_state("no_response")
            limit = SILENCE_LIMITS.get(self.state)
            if limit and now - self.since > limit:
                self._fault(f"Алкотестер замолчал посреди теста: шаг «{STEP_NAMES[self.state]}» "
                            f"длится больше {limit} с")
            if not self.quick and self.state == "cooldown" and now - self.since > PAUSE:
                self._set_state("stopped")
            if not self.quick and self.state == "blow" and now - self.since > self.rearm:
                self._log("info", b"", f"Выдоха не было {self.rearm:g} с: тест остановлен")
                self._send_stop("Завершение теста: не дождались выдоха")
                self._set_state("stopped")
            if now - self.stats_logged > 600:
                self._log_stats("Статистика за 10 минут")
            if self.quick:
                self._keep_ready(now)

    def _handle(self, kind, data, order):
        if kind == "junk":
            with self.lock:
                self._log("rx", data, "Байты не по формату протокола (или с неверным CRC)")
                self._count("junk")
                now = time.time()
                self.junk_times.append(now)
                if (len(self.junk_times) == self.junk_times.maxlen and now - self.junk_times[0] < 60
                        and now - self.junk_warned > 60):
                    self.junk_warned = now
                    self._log("error", b"", "Много испорченных пакетов за минуту: проверьте кабель и разъём")
            return
        text, event = describe(data)
        with self.lock:
            own_stop = event and event[0] == "stop_ack" and time.time() - self.stop_sent > 1
            if own_stop:
                text = "Устройство само завершило тест"
            if order == "swapped":
                text += " [CRC младшим байтом вперёд, не как в документе]"
            self._log("rx", data, text)
            self.deadline = None
            if event is None:
                return
            state, value = event
            if own_stop and self.state in ACTIVE:
                self.start_at = None
                self._set_state("stopped")
            if state in ("unit_ack", "stop_ack"):
                return
            if self.state == "cooldown" and state != "result":
                self._log("info", b"", "Идёт пауза после прерванных выдохов: шаг не меняю")
                return
            if state == "result" and not self._result_ok(value):
                return
            if state == "error":
                self.errors_in_row += 1
                self._count("blow_errors")
                value = self.errors_in_row
            self._set_state(state, value)
            if state == "error" and value >= ERRORS_BEFORE_PAUSE:
                self.errors_in_row = 0
                self._log("info", b"", f"{value} прерванных выдоха подряд: останавливаю тест на {PAUSE} с, "
                                       "чтобы человек отдышался")
                self._send_stop("Завершение теста: пауза после прерванных выдохов")
                self._set_state("cooldown", PAUSE)
            if state == "collecting":
                self.last = None  # новый выдох, старый результат больше не показываем
            if state == "result":
                self.errors_in_row = 0
                self._count("results")
                self.last = (value, self.unit, time.time())
                # по протоколу после результата нужно отправить стоп
                self._send_stop("Завершение теста после результата")

    def _result_ok(self, value):
        """Показывать ли результат: он должен прийти после выдоха и быть правдоподобным."""
        if self.state not in ("collecting", "analyzing"):
            # например, хвост от теста, который начался до запуска скрипта
            self._log("error", b"", f"Результат пришёл не после выдоха (шаг: {self.state}), не показываю")
            self._send_stop("Завершение теста после лишнего результата")
            if self.state in ACTIVE:
                self._set_state("stopped")
            return False
        if value > MAX_RAW:
            self._fault(f"Значение {value} вне диапазона алкотестера: сбой датчика или испорченный пакет")
            return False
        return True


# ---------- эмулятор для --demo ----------

class Emulator:
    """Отвечает как ATZS-859FU; паузы взяты из журнала с настоящего устройства.

    auto_blow: "дуть" самому через 1,5 с после приглашения (для --cli),
    иначе ждать blow() - кнопки "Дунуть" в демо-интерфейсе. Каждый третий выдох прерывается.
    """

    def __init__(self, auto_blow=True):
        self.master, self.slave = os.openpty()
        self.path = os.ttyname(self.slave)
        self.parser = FrameParser()
        self.lock = threading.Lock()
        self.plan = []
        self.auto_blow = auto_blow
        self.waiting = False  # отправлено приглашение "дуйте", выдоха ещё не было
        self.blows = 0
        self.mute_until = 0.0  # до этого времени молчит, как только что включённое устройство
        threading.Thread(target=self._loop, daemon=True).start()

    def blow(self):
        with self.lock:
            if not self.waiting:
                return False
            self._blow(0)
            return True

    def _blow(self, delay):
        self.waiting = False
        self.blows += 1
        if self.blows % 3 == 0:
            steps = [(0, make_frame(0x04)), (0.9, make_frame(0x05)), (2.94, make_frame(0x03))]
        else:
            raw = 53 if self.blows % 2 else 0
            steps = [(0, make_frame(0x04)), (2.04, make_frame(0x06)),
                     (6.18, make_frame(0x07, raw.to_bytes(2, "big")))]
        self._schedule(steps, delay)

    def _schedule(self, steps, delay=0):
        now = time.time() + delay
        self.plan = sorted(self.plan + [(now + dt, frame) for dt, frame in steps])

    def _on_frame(self, fr):
        kind = fr[2]
        if kind == 0x02:
            self.plan, self.waiting = [], False
            self._schedule([(0.02 + 1.02 * i, make_frame(0x02, [4 - i])) for i in range(4)]
                           + [(4.1, make_frame(0x03))])
            if self.auto_blow:
                self._blow(5.6)
        elif kind == 0x08:
            self.plan, self.waiting = [], False
            os.write(self.master, fr)
        elif kind == 0x17:
            os.write(self.master, make_frame(0x17))

    def _loop(self):
        while True:
            ready, _, _ = select.select([self.master], [], [], 0.05)
            data = os.read(self.master, 256) if ready else b""
            if time.time() < self.mute_until:
                continue
            with self.lock:
                for kind, fr, _ in self.parser.feed(data, time.time()):
                    if kind == "frame":
                        self._on_frame(fr)
                now = time.time()
                while self.plan and self.plan[0][0] <= now:
                    frame = self.plan.pop(0)[1]
                    os.write(self.master, frame)
                    if frame[2] == 0x03 and not self.plan:
                        self.waiting = True


# ---------- журнал и веб-интерфейс ----------

class CsvJournal:
    def __init__(self, directory):
        os.makedirs(directory, exist_ok=True)
        self.path = os.path.join(directory, time.strftime("alcotest-%Y%m%d-%H%M%S.csv"))
        self.file = open(self.path, "w", newline="", encoding="utf-8")
        self.writer = csv.writer(self.file)
        # направление: tx - к устройству, rx - от него, raw - сырые куски из порта до разбора,
        # state - смена шага теста, ui - действия на экране, info - сведения, error - сбои
        self.writer.writerow(["время", "секунд_с_запуска", "направление", "состояние", "hex", "расшифровка"])
        self.lock = threading.Lock()

    def __call__(self, e):
        with self.lock:
            self.writer.writerow([e["t"], e["dt"], e["dir"], e["state"], e["hex"], e["text"]])
            self.file.flush()


class Hub:
    """Раздаёт события всем открытым страницам интерфейса."""

    def __init__(self):
        self.clients = set()
        self.history = collections.deque(maxlen=400)
        self.lock = threading.Lock()

    def publish(self, msg):
        data = json.dumps(msg, ensure_ascii=False)
        with self.lock:
            if msg["type"] == "log":
                self.history.append(data)
            for q in self.clients:
                q.put(data)

    def subscribe(self):
        q = queue.Queue()
        with self.lock:
            self.clients.add(q)
            return q, list(self.history)

    def unsubscribe(self, q):
        with self.lock:
            self.clients.discard(q)


def make_handler(dev, hub, emulator=None):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass  # не засорять консоль запросами

        def do_GET(self):
            if self.path in ("/", "/index.html"):
                with open(os.path.join(HERE, "ui.html"), "rb") as f:
                    body = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)
            elif self.path == "/events":
                self._events()
            else:
                self.send_error(404)

        def do_POST(self):
            # принимаем только JSON, чтобы чужая страница в браузере не могла жать кнопки
            if not self.headers.get("Content-Type", "").startswith("application/json"):
                return self._json(415, {"ok": False, "error": "Нужен JSON"})
            size = int(self.headers.get("Content-Length") or 0)
            try:
                body = json.loads(self.rfile.read(size) or b"{}")
                dev.note("ui", f"Экран ({self.client_address[0]}): {self.path} "
                               f"{json.dumps(body, ensure_ascii=False)}")
                if self.path == "/api/start":
                    dev.start_test()
                elif self.path == "/api/stop":
                    dev.stop_test()
                elif self.path == "/api/unit":
                    dev.set_unit(int(body["unit"]))
                elif self.path == "/api/quick":
                    dev.set_quick(bool(body["on"]))
                elif self.path == "/api/demo/blow" and emulator:
                    if not emulator.blow():
                        raise RuntimeError("Эмулятор сейчас не ждёт выдоха")
                else:
                    return self._json(404, {"ok": False, "error": "Нет такого действия"})
            except (RuntimeError, ValueError, KeyError, OSError) as e:
                dev.note("error", f"Экран: {self.path} отклонено: {e}")
                return self._json(409, {"ok": False, "error": str(e)})
            self._json(200, {"ok": True})

        def _json(self, code, obj):
            body = json.dumps(obj, ensure_ascii=False).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _events(self):
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            q, history = hub.subscribe()
            dev.note("ui", f"Экран подключился: {self.client_address[0]}, {self.headers.get('User-Agent', '')}")
            try:
                self._sse(json.dumps(dev.snapshot(), ensure_ascii=False))
                for data in history:
                    self._sse(data)
                while True:
                    try:
                        self._sse(q.get(timeout=15))
                    except queue.Empty:
                        self.wfile.write(b": ping\n\n")
                        self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError):
                pass
            finally:
                hub.unsubscribe(q)
                dev.note("ui", f"Экран отключился: {self.client_address[0]}")

        def _sse(self, data):
            self.wfile.write(f"data: {data}\n\n".encode())
            self.wfile.flush()

    return Handler


def run_web(args):
    hub = Hub()
    journal = CsvJournal(args.log_dir)
    emulator = Emulator(auto_blow=False) if args.demo else None
    path = emulator.path if emulator else args.port
    dev = Alcotester(path, args.baud, hub.publish, journal, demo=args.demo,
                     unit=args.unit, quick=args.quick, rearm=args.rearm)
    try:
        server = ThreadingHTTPServer((args.host, args.http_port), make_handler(dev, hub, emulator))
    except OSError as e:
        print(f"Не удалось занять порт {args.http_port}: {e}. Укажите другой: --http-port 8081")
        return 1
    server.daemon_threads = True
    shown = "localhost" if args.host in ("127.0.0.1", "0.0.0.0") else args.host
    print(f"Интерфейс: http://{shown}:{args.http_port}")
    if args.host == "0.0.0.0":
        print("Внимание: интерфейс доступен всем в этой сети")
    print("Порт алкотестера: " + ("эмулятор" if args.demo else
                                  "ищу сам среди переходников CH340" if path == "auto" else path))
    print(f"Журнал: {journal.path}")
    print("Остановить: Ctrl+C")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    dev.log_stats("Итог за запуск")
    return 0


def run_find(args):
    """Показать все последовательные USB-порты и найти среди них алкотестер."""
    if args.port != "auto":
        print("--find перебирает порты сам, --port не нужен")
    path, _, notes, busy = scan_ports(args.baud, first=False)
    print("Последовательные USB-порты:")
    for note in notes or ["не видно ни одного (ttyUSB, ttyACM)"]:
        print("  " + note)
    if path:
        print(f"\nАлкотестер ATZS-859FU: {path}\n  {usb_info(path)}")
        return 0
    print("\nАлкотестер не найден" + (": переходник CH340 занят другой программой" if busy else ""))
    return 1


def run_cli(args):
    finished = threading.Event()

    def emit(m):
        if m["type"] == "log":
            arrow = {"tx": "->", "rx": "<-", "info": "  ", "ui": "UI", "error": "!!"}.get(m["dir"], m["dir"])
            print(f"{m['t']}  {arrow} {m['hex']:<23} {m['text']}", flush=True)
        elif m["type"] == "state" and m["state"] == "result":
            print(f"\nРезультат: сырое значение {m['value']}; если делить на 1000, "
                  f"как в примере документа, — {m['value'] / 1000:.3f}\n", flush=True)
            finished.set()
        elif m["type"] == "state" and m["state"] in ("error", "fault", "no_response"):
            finished.set()

    journal = CsvJournal(args.log_dir)
    path = Emulator().path if args.demo else args.port
    dev = Alcotester(path, args.baud, emit, journal, demo=args.demo,
                     unit=None if args.listen else args.unit)
    end = time.time() + 5
    while not dev.connected and time.time() < end:
        time.sleep(0.1)
    if not dev.connected:
        if dev.state == "busy":
            print(f"Порт занят: {dev.value}. Закройте эту программу и запустите скрипт снова")
        else:
            print(f"Порт так и не открылся. {dev.value or ''}")
        return 1
    try:
        if args.listen:
            print("Только слушаю порт, ничего не отправляю. Выход: Ctrl+C")
        else:
            time.sleep(0.5)  # дать устройству ответить на команду единиц
            dev.start_test()
        end = time.time() + args.timeout
        while time.time() < end and not (finished.is_set() and not args.listen):
            time.sleep(0.1)
        time.sleep(1.5)  # дать прийти ответу на "стоп"
    except KeyboardInterrupt:
        pass
    dev.log_stats("Итог за запуск")
    print(f"Журнал: {journal.path}")
    return 0


def main():
    p = argparse.ArgumentParser(description="Проверка алкотестера ATZS-859FU")
    p.add_argument("--port", default=DEFAULT_PORT,
                   help="последовательный порт; auto (по умолчанию) — найти самому среди переходников CH340")
    p.add_argument("--find", action="store_true",
                   help="только показать порты и на каком из них алкотестер, затем выйти")
    p.add_argument("--baud", type=int, default=9600, choices=sorted(BAUDS),
                   help="скорость порта; ATZS-859FU работает на 9600")
    p.add_argument("--unit", type=int, default=1, choices=sorted(UNITS),
                   help="единицы при подключении: 0 %%BAC, 1 мг/л, 2 мг/100 мл, 3 г/л")
    p.add_argument("--quick", action="store_true",
                   help="запустить в быстром режиме: алкотестер сам ждёт выдоха")
    p.add_argument("--rearm", type=float, default=60,
                   help="сколько секунд ждать выдоха: в быстром режиме потом тест перезапускается, "
                        "по кнопке — останавливается")
    p.add_argument("--cli", action="store_true", help="консольный режим без интерфейса")
    p.add_argument("--listen", action="store_true", help="с --cli: только слушать порт")
    p.add_argument("--timeout", type=float, default=60, help="с --cli: сколько секунд ждать результата")
    p.add_argument("--demo", action="store_true", help="встроенный эмулятор вместо устройства")
    p.add_argument("--host", default="127.0.0.1",
                   help="адрес интерфейса; 0.0.0.0 откроет его для других компьютеров в сети")
    p.add_argument("--http-port", type=int, default=8080, help="порт интерфейса")
    p.add_argument("--log-dir", default=os.path.join(HERE, "alcotest-logs"), help="папка для журналов")
    args = p.parse_args()

    def on_term(signum, frame):
        raise KeyboardInterrupt  # чтобы и после pkill в журнал записался итог

    signal.signal(signal.SIGTERM, on_term)
    signal.signal(signal.SIGHUP, on_term)  # окно терминала закрыли
    if args.find:
        return run_find(args)
    return run_cli(args) if args.cli else run_web(args)


if __name__ == "__main__":
    sys.exit(main())
